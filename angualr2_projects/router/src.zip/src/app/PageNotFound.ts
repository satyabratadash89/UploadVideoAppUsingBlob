/**
 * Created by gouri.rohit.itagi on 5/17/2017.
 */

import {Component} from "@angular/core";
@Component({
  template:`<h2 [ngStyle]="{'color':'red'}">Page cannot be found</h2>`
})

export class PageNotFound{

}
