import { Component } from '@angular/core';

@Component({
    template: `
        <div class="padded darker-blue">
            <h1>Large</h1>
        </div>`
})
export class LargeComponent {}
