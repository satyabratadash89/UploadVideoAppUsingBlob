import {Component} from '@angular/core';

@Component({
    template: `
        <div class="padded darker-blue">
            <p>Small</p>
        </div>`
})
export class SmallComponent {}