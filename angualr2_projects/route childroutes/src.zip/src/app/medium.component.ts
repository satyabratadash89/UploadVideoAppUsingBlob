import {Component} from '@angular/core';

@Component({
    template: `
        <div class="padded darker-blue">
            <h3>Medium</h3>
        </div>`
})
export class MediumComponent {}