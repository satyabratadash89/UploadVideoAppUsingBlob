
import {Component} from "@angular/core";

@Component({
  selector: 'user-comp',
  styles:[`
h1{
  color:green;
}
`],
  template: '<h1> this is from user component</h1>'

})
export class usercomponent{

}
