import {Component} from "@angular/core";

@Component({
  selector:'prd-comp',
  templateUrl:'./productcomponent.html',
  styleUrls:['./productcomponent.css']

})
export class productcomponent{

}
